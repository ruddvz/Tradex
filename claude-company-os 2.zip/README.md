# Claude Company OS — v2

**Give your company a shared brain. Ship faster. Think less. Repeat less.**

Claude Company OS turns Claude Code into a full AI workforce — one that knows your stack, follows your standards, handles handoffs between agents, tracks execution phases, and remembers what happened in previous sessions.

No paid tools. No orchestration frameworks. Just folders and markdown files you fill in once, commit, and benefit from forever.

---

## What This Gives You

| Feature | What it does |
|---|---|
| **Shared rulebook** | Every Claude session follows the same standards, regardless of who runs it |
| **28+ specialized agents** | Frontend, backend, ops, data, security, reviewer agents — each knows exactly what it owns |
| **Master workflow** | 8-phase development loop covering planning → TDD → execution → review → docs → push |
| **Session handoff log** | Agents write `planning/CHANGELOG.md` so the next session picks up instantly |
| **Execution plan tracking** | Phase-based `planning/EXECUTION-PLAN.md` with checkbox state per slice |
| **Active task queue** | `planning/ACTIVE.md` is the live work queue — always reflects reality |
| **Token-efficient routing** | Model routing matrix (Haiku/Sonnet/Opus) so you spend tokens on the right work |
| **GSD system** | Get Stuff Done — the system that prevents agent drift and scope creep |
| **Failure protocol** | Three-attempts-then-escalate rule prevents infinite loops |
| **Design system template** | Design tokens, component rules, responsive rules for the UI team |

---

## Folder Structure

```
your-project/
├── .claude/
│   ├── workflow-101.md              ← Master 8-phase workflow (read this first)
│   └── skills/
│       ├── core/                   ← Applies to every agent, every task
│       │   ├── company.md          ← Who you are, your stack, your rules
│       │   ├── code-style.md       ← Formatting, naming, patterns
│       │   ├── communication.md    ← Writing standards, PRs, error messages
│       │   ├── orchestrator.md     ← Multi-agent coordination brain
│       │   ├── handoff-protocol.md ← How agents pass work to each other
│       │   ├── failure-handling.md ← What to do when things break
│       │   ├── token-efficiency.md ← Model routing + token budget rules
│       │   └── agent-registry.md  ← Full roster of available agents
│       ├── team/                   ← One file per role on your team
│       │   ├── frontend.md         ← UI, components, styling, routing
│       │   ├── backend.md          ← APIs, database, auth, business logic
│       │   ├── ops.md              ← Deployments, infra, CI/CD, monitoring
│       │   └── data.md             ← Pipelines, analytics, ML workflows
│       └── project/                ← This specific project's context
│           ├── architecture.md     ← System design, data model, decisions
│           ├── workflows.md        ← Step-by-step playbooks for common tasks
│           └── decisions.md        ← Why things are the way they are
├── planning/
│   ├── ACTIVE.md                   ← Live task queue (read at session start)
│   ├── CHANGELOG.md                ← Session handoff log (newest first)
│   └── EXECUTION-PLAN.md          ← Phase-based roadmap with checkboxes
├── memory/
│   └── context-log.md              ← Agents write here; shared persistent memory
├── docs/
│   ├── how-to-add-skills.md
│   ├── skill-template.md
│   └── design-system-template.md  ← Design tokens and UI rules template
└── scripts/
    └── setup.sh                    ← Interactive setup script
```

---

## Quick Start

### 1. Copy into your project

```bash
cp -r claude-company-os/.claude your-project/.claude
cp -r claude-company-os/planning your-project/planning
cp -r claude-company-os/memory your-project/memory
```

### 2. Run setup

```bash
bash scripts/setup.sh
```

The setup script asks for your company name, tech stack, and team roles. It fills in placeholders across all skill files automatically.

### 3. Fill in the gaps

The setup script handles the easy parts. These sections need your judgment:

| File | What to add |
|---|---|
| `skills/core/company.md` | Non-negotiables specific to your team; folder structure |
| `skills/core/code-style.md` | Your formatter config; naming conventions |
| `skills/team/frontend.md` | Design tokens (colors, fonts, spacing) |
| `skills/team/backend.md` | ORM, auth provider, required env vars |
| `skills/project/architecture.md` | System diagram; data model; key decisions |
| `planning/EXECUTION-PLAN.md` | Your initial roadmap phases and slices |

### 4. Commit both directories

```bash
git add .claude/ planning/ memory/
git commit -m "feat: add Claude Company OS v2"
```

---

## The 8-Phase Workflow (Summary)

Every feature goes through these phases. Full details in `.claude/workflow-101.md`.

| Phase | Name | What happens |
|---|---|---|
| 0 | Context | Read CHANGELOG, ACTIVE, EXECUTION-PLAN before anything |
| 1 | Planning | Blast-radius check, feature branch, planner agent |
| 2 | TDD Setup | Write failing tests first |
| 3 | Execution | Implement, go green, refactor |
| 4 | Verification | Build + tests + E2E |
| 5 | Quality Review | code-reviewer + security-reviewer in parallel |
| 6 | Docs & Memory | Update codemaps, EXECUTION-PLAN, ACTIVE |
| 7 | Wrap-up | Ask user for next step |
| 8 | Safe Push | Build → lint → test → diff scan → commit → push |

---

## Session Handoff Protocol

This is the #1 feature of the OS. Every agent writes a CHANGELOG entry after every commit so the next session (or next agent) picks up instantly.

**Mandatory format (add to `planning/CHANGELOG.md` after every commit):**

```markdown
## YYYY-MM-DD HH:MM — branch-name — slice id: short title
- Commit: <sha> (type: subject)
- Files touched: path1, path2
- Tests added/changed: count (file)
- Build: pass | fail (reason)
- Status: done | wip | blocked (reason)
- Next up: slice id + short title OR explicit question for next agent
- Notes: gotchas, partial state, deferred decisions
```

**Rule:** `Next up:` is MANDATORY. Never leave it empty. This is the single most important line.

---

## Token Efficiency

The OS uses a three-tier model routing system to minimize cost:

| Tier | Model | When to use |
|---|---|---|
| T1 | Haiku | File ops, git, boilerplate, simple CRUD |
| T2 | Sonnet | Multi-file features, debugging, reviews (80% of work) |
| T3 | Opus | Architecture, security audits, gnarly bugs Sonnet failed |

Full routing rules in `skills/core/token-efficiency.md`.

---

## Adding New Skills

See `docs/how-to-add-skills.md` for the full guide.

Short version:
1. Copy `docs/skill-template.md` to the right subfolder
2. Fill in the template
3. PR → team reviews → everyone benefits immediately

---

## Customizing Your Workforce

- No dedicated ops role? Delete `team/ops.md`
- Have a mobile team? Add `team/mobile.md`
- Running multiple projects? Add a `project/` subfolder per project
- Need a security team? Add `team/security.md`

The system scales with your team. One skill file per domain.
